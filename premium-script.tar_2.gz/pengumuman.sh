#!/bin/bash
# Script Nobita 95
# Dilarang Keras Mengambil/mencuplik/mengcopy sebagian atau seluruh script ini.
# Hak Cipta NobiNobita95 (Dilindungi Undang-Undang nomor 19 Tahun 2002)
curl Nobi Nobita/index.html
echo ""